# Paper proof sources

Lean 4.24.0; Mathlib version is pinned in lean/lakefile.toml.
With Lean installed, run from lean/:

    lake exe cache get
    lake build
    lake env lean Audit.lean

See PROOF_COVERAGE.md for the exact coverage and evidence/ for the retained successful build. Dependencies and compiled caches are not bundled.
