# Formal proof coverage


The proof development uses Lean 4.24.0 and Mathlib 4.24.0 (revision `f897ebcf72cd`; full pin in the supplement). Strict validity is a recursive predicate: children must be valid and every right child must have positive value. Value functions may use Mathlib's total real logarithm internally, but mathematical conclusions about terms carry the strict-validity predicate. This prevents a totalized logarithm from silently changing the paper's language.


| Result | Executed formal coverage |
|---|---|
| Arithmetic and compilation | `Arithmetic`, `Compiler`: exact values, natural domains, and 57/14/128/299 node counts |
| Positive-seed density | `Density`, `ExactSeeds`: strict syntax, contraction, geometric rate, dense ground orbits |
| Dense exact seeds | `DenseExactSeeds`: an exact witness in every positive interval and $\overline{\mathcal U}=[0,\infty)$ |
| Analytic dichotomy | `ExactSeeds`: all-positive-or-countable; equivalence with a local interval identity |
| Compact approximation | `PolynomialApproximation`, `Approximation`, `FiniteApproximation`: Stone–Weierstrass, rational compilation, declared finite variables and an open valid neighborhood |
| Replacement stability | `ParameterStability`, `CompactTransfer`: uniform value/domain stability and actual substitution |
| Domain obstructions | `NonpositiveObstruction`, `DomainWitness`: origin obstruction and one fixed positive leaf; `Density`: no initialized finite iterate equals 1 |
| Relational certificates | `RelationCertificates`: scalar/column semantics, least closure, complete exclusion, intersection and definedness-preserving transport |
| General cost bounds | `RelationCertificates`: Bellman lower bounds and attaining-witness optimality |


The displayed axioms are limited to Lean's standard `propext`, `Classical.choice`, and `Quot.sound`; some structural and size results use none. The sources contain no admitted proofs or custom axioms. The packet retains source hashes, compiler output, and axiom reports.

The global-basin part of Theorem 2 below 1, the local derivative, the constant-free positive-coordinate sufficiency direction of Theorem 5, o-minimal results, finite-semiring classification, and specialized finite cost tables have ordinary proofs or executed finite certificates as indicated. They are not collectively described as Lean-verified. Nor does the development verify the Python evaluator, table checker, or a native runtime adapter. The positive-named-constant approximation direction is fully formalized, including polynomial approximation.


The final delivered source hashes and executed environment are recorded in `evidence/lean_build_receipt.json`.
