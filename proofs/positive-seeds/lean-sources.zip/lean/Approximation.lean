import CompactTransfer
import PolynomialApproximation

/-! Full uniform approximation from every positive seed, with strict open-domain guarantees. -/
noncomputable section
open Set Topology
namespace StrictEML

/-- Every continuous real-valued function on a compact environment set is uniformly approximated
by one finite EML term over a given positive named constant. -/
theorem positive_seed_compact_approximation {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (f : C(K,ℝ)) {c ε : ℝ} (hc : 0 < c) (hε : 0 < ε) :
    ∃ u : Term, ∀ x : K,
      parameterValid u (c,x.val) ∧ |parameterVal u (c,x.val) - f x| < ε := by
  obtain ⟨p,hp⟩ := rational_polynomial_approximation hK f (half_pos hε)
  have ht : ∀ ρ ∈ K, Valid p.compile ρ := fun ρ _ => (p.compile_realizes ρ).1
  obtain ⟨u,hu⟩ := compact_seed_replacement p.compile hK ht hc (half_pos hε)
  refine ⟨u, fun x => ?_⟩
  obtain ⟨hdom,herr⟩ := hu x.val x.property
  rw [(p.compile_realizes x.val).2] at herr
  refine ⟨hdom, ?_⟩
  have htriangle := abs_sub_le (parameterVal u (c,x.val)) (p.value x.val) (f x)
  have happ := hp x
  linarith

/-- The same approximation is defined on an open neighborhood of the entire compact set. -/
theorem positive_seed_compact_open_approximation {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (f : C(K,ℝ)) {c ε : ℝ} (hc : 0 < c) (hε : 0 < ε) :
    ∃ (u : Term) (U : Set (Nat → ℝ)), IsOpen U ∧ K ⊆ U ∧
      (∀ ρ ∈ U, parameterValid u (c,ρ)) ∧
      ∀ x : K, |parameterVal u (c,x.val) - f x| < ε := by
  obtain ⟨u,hu⟩ := positive_seed_compact_approximation hK f hc hε
  refine ⟨u,{ρ | parameterValid u (c,ρ)}, ?_, ?_, ?_, ?_⟩
  · exact (parameter_domain_open u).preimage (continuous_const.prodMk continuous_id)
  · intro ρ hρ; exact (hu ⟨ρ,hρ⟩).1
  · intro ρ hρ; exact hρ
  · intro x; exact (hu x).2

end StrictEML
