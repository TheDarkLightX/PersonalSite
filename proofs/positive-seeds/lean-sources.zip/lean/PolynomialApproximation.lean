import RationalTerms
import Mathlib.Topology.ContinuousMap.StoneWeierstrass
import Mathlib.Topology.Algebra.Order.Archimedean

/-! Rational polynomial syntax and its density on arbitrary compact sets of environments. -/
noncomputable section
open Set Topology
namespace StrictEML

inductive PolyTerm where
  | rat : ℚ → PolyTerm
  | var : Nat → PolyTerm
  | add : PolyTerm → PolyTerm → PolyTerm
  | mul : PolyTerm → PolyTerm → PolyTerm
  | neg : PolyTerm → PolyTerm

namespace PolyTerm

def value : PolyTerm → (Nat → ℝ) → ℝ
  | .rat q, _ => q
  | .var n, ρ => ρ n
  | .add a b, ρ => value a ρ + value b ρ
  | .mul a b, ρ => value a ρ * value b ρ
  | .neg a, ρ => -value a ρ

def compile : PolyTerm → Term
  | .rat q => ratTerm q
  | .var n => .var n
  | .add a b => A a.compile b.compile
  | .mul a b => M a.compile b.compile
  | .neg a => S (ratTerm 0) a.compile

theorem compile_realizes (p : PolyTerm) (ρ : Nat → ℝ) : Realizes p.compile ρ (p.value ρ) := by
  induction p with
  | rat q => exact ratTerm_realizes q ρ
  | var n => exact repVar ρ n
  | add a b ia ib => exact repA ia ib
  | mul a b ia ib => exact repM ia ib
  | neg a ia => simpa only [Rat.cast_zero,zero_sub] using repS (ratTerm_realizes 0 ρ) ia

theorem continuous_value (p : PolyTerm) : Continuous p.value := by
  induction p with
  | rat q => exact continuous_const
  | var n => exact continuous_apply n
  | add a b ia ib => exact ia.add ib
  | mul a b ia ib => exact ia.mul ib
  | neg a ia => exact ia.neg

def onSet (p : PolyTerm) (K : Set (Nat → ℝ)) : C(K,ℝ) :=
  ⟨fun x => p.value x.val, p.continuous_value.comp continuous_subtype_val⟩

@[simp] theorem onSet_apply (p : PolyTerm) (K : Set (Nat → ℝ)) (x : K) :
    p.onSet K x = p.value x.val := rfl

end PolyTerm

def rationalPolynomials (K : Set (Nat → ℝ)) : Subring C(K,ℝ) where
  carrier := {f | ∃ p : PolyTerm, p.onSet K = f}
  zero_mem' := ⟨.rat 0, by ext x; simp [PolyTerm.value]⟩
  one_mem' := ⟨.rat 1, by ext x; simp [PolyTerm.value]⟩
  add_mem' := by
    rintro f g ⟨p,rfl⟩ ⟨q,rfl⟩
    exact ⟨.add p q, by ext x; rfl⟩
  mul_mem' := by
    rintro f g ⟨p,rfl⟩ ⟨q,rfl⟩
    exact ⟨.mul p q, by ext x; rfl⟩
  neg_mem' := by
    rintro f ⟨p,rfl⟩
    exact ⟨.neg p, by ext x; rfl⟩

theorem real_constant_mem_closure (K : Set (Nat → ℝ)) [CompactSpace K] (r : ℝ) :
    algebraMap ℝ C(K,ℝ) r ∈ (rationalPolynomials K).topologicalClosure := by
  refine (Rat.denseRange_cast (𝕜 := ℝ)).induction_on r ?_ ?_
  · exact (rationalPolynomials K).isClosed_topologicalClosure.preimage
      (continuous_algebraMap ℝ C(K,ℝ))
  · intro q
    apply (rationalPolynomials K).le_topologicalClosure
    exact ⟨.rat q, by ext x; simp [PolyTerm.value]⟩

def approximationAlgebra (K : Set (Nat → ℝ)) [CompactSpace K] : Subalgebra ℝ C(K,ℝ) :=
  { (rationalPolynomials K).topologicalClosure.toSubsemiring with
    algebraMap_mem' := real_constant_mem_closure K }

theorem approximationAlgebra_separates (K : Set (Nat → ℝ)) [CompactSpace K] :
    (approximationAlgebra K).SeparatesPoints := by
  intro x y hxy
  have hn : ∃ n, x.val n ≠ y.val n := by
    by_contra h
    push_neg at h
    exact hxy (Subtype.ext (funext h))
  obtain ⟨n,hn⟩ := hn
  refine ⟨fun z : K => z.val n, ?_, hn⟩
  refine ⟨(PolyTerm.var n).onSet K, ?_, rfl⟩
  exact (rationalPolynomials K).le_topologicalClosure ⟨.var n,rfl⟩

/-- A checked Stone-Weierstrass application with rational, finitely named coefficients. -/
theorem rational_polynomial_approximation {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (f : C(K,ℝ)) {ε : ℝ} (hε : 0 < ε) :
    ∃ p : PolyTerm, ∀ x : K, |p.value x.val - f x| < ε := by
  letI : CompactSpace K := isCompact_iff_compactSpace.mp hK
  have hf := ContinuousMap.continuousMap_mem_subalgebra_closure_of_separatesPoints
    (approximationAlgebra K) (approximationAlgebra_separates K) f
  have hclosed : IsClosed (approximationAlgebra K : Set C(K,ℝ)) :=
    (rationalPolynomials K).isClosed_topologicalClosure
  change f ∈ closure (approximationAlgebra K : Set C(K,ℝ)) at hf
  rw [hclosed.closure_eq] at hf
  change f ∈ closure (rationalPolynomials K : Set C(K,ℝ)) at hf
  obtain ⟨g,hg,hd⟩ := Metric.mem_closure_iff.mp hf ε hε
  obtain ⟨p,rfl⟩ := hg
  refine ⟨p, fun x => ?_⟩
  have hx := (ContinuousMap.dist_lt_iff hε).mp hd x
  simpa only [Real.dist_eq, abs_sub_comm, PolyTerm.onSet_apply] using hx

end StrictEML
