import ExactSeeds
import ParameterStability
import RationalTerms
import UniformContract
import Mathlib.Topology.Order.IntermediateValue

noncomputable section
open Set Filter Topology
namespace ExactSeeds
open SeedTerm

/-- The four-node contraction context, with every leaf replaced by `s`. -/
def stepTerm (s : SeedTerm) : SeedTerm :=
  node (node s (node (node s s) s)) s

def bootstrap : Nat → SeedTerm
  | 0 => node leaf leaf
  | n+1 => stepTerm (bootstrap n)

lemma value_stepTerm (s : SeedTerm) (x : ℝ) :
    value (stepTerm s) x = PositiveSeeds.step (value s x) := rfl

lemma valid_stepTerm (s : SeedTerm) {x : ℝ} (hs : Valid s x)
    (hx : 1 < value s x) : Valid (stepTerm s) x := by
  have hp : 0 < value s x := by linarith
  have hi := PositiveSeeds.step_inner_pos hx
  exact ⟨⟨hs, ⟨⟨hs, hs, hp⟩, hs, hp⟩, hi⟩, hs, hp⟩

lemma value_bootstrap (n : Nat) (x : ℝ) :
    value (bootstrap n) x = PositiveSeeds.contract (Real.exp x - Real.log x) n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [bootstrap, value_stepTerm, ih, PositiveSeeds.contract]

lemma valid_bootstrap (n : Nat) {x : ℝ} (hx : 0 < x) : Valid (bootstrap n) x := by
  have hinit : 1 < Real.exp x - Real.log x := by linarith [PositiveSeeds.self_growth hx]
  induction n with
  | zero => exact ⟨trivial, trivial, hx⟩
  | succ n ih =>
      apply valid_stepTerm _ ih
      rw [value_bootstrap]
      exact PositiveSeeds.contract_gt_one hinit n

lemma value_bootstrap_gt_one (n : Nat) {x : ℝ} (hx : 0 < x) :
    1 < value (bootstrap n) x := by
  rw [value_bootstrap]
  apply PositiveSeeds.contract_gt_one
  linarith [PositiveSeeds.self_growth hx]

def SeedTerm.nodes : SeedTerm → Nat
  | leaf => 0
  | node a b => 1 + a.nodes + b.nodes

lemma nodes_stepTerm (s : SeedTerm) : (stepTerm s).nodes = 4 + 5 * s.nodes := by
  simp only [stepTerm, SeedTerm.nodes]
  omega

lemma nodes_bootstrap (n : Nat) : (bootstrap n).nodes + 1 = 2 * 5 ^ n := by
  induction n with
  | zero => norm_num [bootstrap, SeedTerm.nodes]
  | succ n ih =>
      rw [bootstrap, nodes_stepTerm, pow_succ]
      omega

/-- Replace the named one in an arithmetic tree by a constant-free tree,
identifying every variable with the sole unary input. -/
def eraseOne : StrictEML.Term → SeedTerm → SeedTerm
  | .one, s => s
  | .var _, _ => leaf
  | .node a b, s => node (eraseOne a s) (eraseOne b s)

lemma value_eraseOne (t : StrictEML.Term) (s : SeedTerm) (x : ℝ) :
    value (eraseOne t s) x = StrictEML.parameterVal t (value s x, fun _ => x) := by
  induction t with
  | one => rfl
  | var n => rfl
  | node a b ha hb => simp only [eraseOne, value, StrictEML.parameterVal, ha, hb]

lemma valid_eraseOne (t : StrictEML.Term) (s : SeedTerm) (x : ℝ) (hs : Valid s x) :
    Valid (eraseOne t s) x ↔ StrictEML.parameterValid t (value s x, fun _ => x) := by
  induction t with
  | one => simpa only [eraseOne, StrictEML.parameterValid] using iff_true_intro hs
  | var n => rfl
  | node a b ha hb =>
      simp only [eraseOne, Valid, StrictEML.parameterValid, ha, hb, value_eraseOne]


lemma initial_bounds {a b x : ℝ} (ha : 0 < a) (hx : x ∈ Icc a b) :
    1 < Real.exp x - Real.log x ∧
      Real.exp x - Real.log x ≤ Real.exp b - Real.log a := by
  have hxp : 0 < x := ha.trans_le hx.1
  constructor
  · linarith [PositiveSeeds.self_growth hxp]
  · have he := Real.exp_le_exp.mpr hx.2
    have hl := Real.log_le_log ha hx.1
    linarith

/-- The actual constant-free syntax converges uniformly to one on every
positive compact interval. -/
theorem bootstrap_uniform {a b : ℝ} (ha : 0 < a) (hab : a ≤ b)
    {δ : ℝ} (hδ : 0 < δ) :
    ∃ n : Nat, ∀ x ∈ Icc a b, |value (bootstrap n) x - 1| < δ := by
  have hb : 1 < Real.exp b - Real.log a :=
    (initial_bounds ha (left_mem_Icc.mpr hab)).1.trans_le
      (initial_bounds ha (left_mem_Icc.mpr hab)).2
  obtain ⟨n, hn⟩ := PositiveSeeds.exists_uniform_contract hb hδ
  refine ⟨n, fun x hx => ?_⟩
  rw [value_bootstrap]
  exact hn _ (initial_bounds ha hx).1 (initial_bounds ha hx).2

/-- A uniform constant-free bootstrap plus a rational affine crossing yields
an exact-one seed in every positive interval. -/
theorem exact_seed_between_of_uniform {a b : ℝ} (ha : 0 < a) (hab : a < b)
    (hu : ∀ δ > 0, ∃ n : Nat, ∀ x ∈ Icc a b, |value (bootstrap n) x - 1| < δ) :
    ∃ c : ℝ, a < c ∧ c < b ∧ c ∈ UniversalSeeds := by
  obtain ⟨r, har, hrb⟩ := exists_rat_btwn hab
  let t := StrictEML.A .one (StrictEML.S (.var 0) (StrictEML.ratTerm r))
  have ht (ρ : Nat → ℝ) : StrictEML.Realizes t ρ (1 + (ρ 0 - (r : ℝ))) :=
    StrictEML.repA (StrictEML.repOne ρ)
      (StrictEML.repS (StrictEML.repVar ρ 0) (StrictEML.ratTerm_realizes r ρ))
  let ε : ℝ := min ((r:ℝ) - a) (b - (r:ℝ)) / 2
  have hε : 0 < ε := div_pos (lt_min (sub_pos.mpr har) (sub_pos.mpr hrb)) (by norm_num)
  have hεa : ε < (r:ℝ) - a := by
    dsimp [ε]
    have := min_le_left ((r:ℝ)-a) (b-(r:ℝ))
    linarith
  have hεb : ε < b - (r:ℝ) := by
    dsimp [ε]
    have := min_le_right ((r:ℝ)-a) (b-(r:ℝ))
    linarith
  let K : Set (Nat → ℝ) := (fun x : ℝ => fun _ : Nat => x) '' Icc a b
  have hK : IsCompact K :=
    isCompact_Icc.image (continuous_pi (fun _ => continuous_id))
  have hvalid : ∀ ρ ∈ K, StrictEML.Valid t ρ := fun ρ _ => (ht ρ).1
  obtain ⟨δ, hδ, hnear⟩ := Metric.mem_nhds_iff.mp
    (StrictEML.compact_parameter_stability t hK hvalid hε)
  obtain ⟨n, hn⟩ := hu δ hδ
  let s := eraseOne t (bootstrap n)
  have hxpos (x : ℝ) (hx : x ∈ Icc a b) : 0 < x := ha.trans_le hx.1
  have hparam (x : ℝ) (hx : x ∈ Icc a b) :
      StrictEML.parameterValid t (value (bootstrap n) x, fun _ => x) ∧
      |StrictEML.parameterVal t (value (bootstrap n) x, fun _ => x) -
        StrictEML.val t (fun _ => x)| < ε := by
    apply hnear
    · simpa only [Metric.mem_ball, Real.dist_eq] using hn x hx
    · exact ⟨x, hx, rfl⟩
  have hsvalid (x : ℝ) (hx : x ∈ Icc a b) : Valid s x :=
    (valid_eraseOne t (bootstrap n) x (valid_bootstrap n (hxpos x hx))).mpr (hparam x hx).1
  have herror (x : ℝ) (hx : x ∈ Icc a b) :
      |value s x - (1 + (x - (r:ℝ)))| < ε := by
    dsimp [s]
    rw [value_eraseOne]
    simpa only [(ht (fun _ => x)).2] using (hparam x hx).2
  have hsa : value s a < 1 := by
    have he := (abs_lt.mp (herror a (left_mem_Icc.mpr hab.le))).2
    linarith
  have hsb : 1 < value s b := by
    have he := (abs_lt.mp (herror b (right_mem_Icc.mpr hab.le))).1
    linarith
  have hcont : ContinuousOn (value s) (Icc a b) :=
    fun x hx => (analyticAt_value s (hsvalid x hx)).continuousAt.continuousWithinAt
  obtain ⟨c, hc, hce⟩ := intermediate_value_Icc hab.le hcont ⟨hsa.le, hsb.le⟩
  have hca : a < c := by
    apply lt_of_le_of_ne hc.1
    intro he
    have : value s a = 1 := by simpa [← he] using hce
    exact hsa.ne this
  have hcb : c < b := by
    apply lt_of_le_of_ne hc.2
    intro he
    have : value s b = 1 := by simpa [he] using hce
    exact hsb.ne' this
  exact ⟨c, hca, hcb, ha.trans hca, s, hsvalid c hc, hce⟩

/-- Exact-one seeds meet every nonempty positive open interval. -/
theorem exact_seed_between {a b : ℝ} (ha : 0 < a) (hab : a < b) :
    ∃ c : ℝ, a < c ∧ c < b ∧ c ∈ UniversalSeeds :=
  exact_seed_between_of_uniform ha hab (fun _ hδ => bootstrap_uniform ha hab.le hδ)

/-- The exact seeds are always dense in the positive half-line, regardless
of which branch of the exact-seed dichotomy holds. -/
theorem closure_universalSeeds : closure UniversalSeeds = Set.Ici 0 := by
  apply Set.Subset.antisymm
  · exact closure_minimal (fun _ hx => le_of_lt hx.1) isClosed_Ici
  · intro x hx
    have hx0 : 0 ≤ x := hx
    rw [Metric.mem_closure_iff]
    intro ε hε
    obtain ⟨c, hac, hcb, hc⟩ := exact_seed_between
      (a := x + ε / 4) (b := x + ε / 2) (by linarith) (by linarith)
    refine ⟨c, hc, ?_⟩
    rw [Real.dist_eq, abs_of_neg (by linarith : x - c < 0)]
    linarith


end ExactSeeds
