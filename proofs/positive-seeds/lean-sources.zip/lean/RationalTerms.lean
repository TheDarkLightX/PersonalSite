import Arithmetic

noncomputable section
namespace StrictEML

def natTerm : Nat → Term
  | 0 => S .one .one
  | n+1 => A (natTerm n) .one

theorem natTerm_realizes (n : Nat) (ρ : Nat → ℝ) : Realizes (natTerm n) ρ (n:ℝ) := by
  induction n with
  | zero => simpa [natTerm] using repS (repOne ρ) (repOne ρ)
  | succ n ih => simpa [natTerm] using repA ih (repOne ρ)

def intTerm : Int → Term
  | .ofNat n => natTerm n
  | .negSucc n => S (natTerm 0) (natTerm (n+1))

theorem intTerm_realizes (z : Int) (ρ : Nat → ℝ) : Realizes (intTerm z) ρ (z:ℝ) := by
  cases z with
  | ofNat n => simpa [intTerm] using natTerm_realizes n ρ
  | negSucc n => simpa [intTerm] using repS (natTerm_realizes 0 ρ) (natTerm_realizes (n+1) ρ)

def ratTerm (q : ℚ) : Term := Dpos (intTerm q.num) (natTerm q.den)

theorem ratTerm_realizes (q : ℚ) (ρ : Nat → ℝ) : Realizes (ratTerm q) ρ (q:ℝ) := by
  rw [Rat.cast_def]
  exact repDpos (intTerm_realizes q.num ρ) (natTerm_realizes q.den ρ) (by exact_mod_cast q.pos)

theorem exists_rational_term (q : ℚ) : ∃ t : Term, ∀ ρ, Realizes t ρ (q:ℝ) :=
  ⟨ratTerm q, ratTerm_realizes q⟩

end StrictEML
