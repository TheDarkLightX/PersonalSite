import Density
import Mathlib.Analysis.SpecificLimits.Basic

open Set Filter Topology

namespace PositiveSeeds

lemma contraction_factor_bounds {B : ℝ} (hB : 1 < B) :
    0 ≤ 1 - 2 / (3 * B) ∧ 1 - 2 / (3 * B) < 1 := by
  have hp : 0 < 3 * B := by linarith
  have hd : 2 / (3 * B) ≤ 1 := (div_le_one hp).mpr (by linarith)
  have hpos : 0 < 2 / (3 * B) := div_pos (by norm_num) hp
  constructor <;> linarith

/-- One geometric bound controls every starting point in the interval (1,B]. -/
theorem uniform_contract_bound {b B : ℝ} (hb : 1 < b) (hbB : b ≤ B) (n : ℕ) :
    contract b n - 1 ≤ (1 - 2 / (3 * B)) ^ n * (B - 1) := by
  have hB : 1 < B := lt_of_lt_of_le hb hbB
  have hq := (contraction_factor_bounds hB).1
  induction n with
  | zero => simpa [contract] using hbB
  | succ n ih =>
    have hbn : contract b n ≤ B := by
      have hi : contract b n ≤ b := by
        simpa [contract] using contract_antitone hb (Nat.zero_le n)
      exact le_trans hi hbB
    have hs := step_error_bound (contract_gt_one hb n) hbn
    have hm := mul_le_mul_of_nonneg_left ih hq
    simp only [contract, pow_succ]
    nlinarith

/-- A common finite iteration count approximates 1 uniformly for 1<b<=B. -/
theorem exists_uniform_contract {B δ : ℝ} (hB : 1 < B) (hδ : 0 < δ) :
    ∃ n : ℕ, ∀ b : ℝ, 1 < b → b ≤ B → |contract b n - 1| < δ := by
  have hq := contraction_factor_bounds hB
  have hlim : Tendsto (fun n : ℕ => (1 - 2 / (3 * B)) ^ n * (B - 1)) atTop (𝓝 0) := by
    simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hq.1 hq.2).mul_const (B - 1)
  have hevent : ∀ᶠ n : ℕ in atTop, (1 - 2 / (3 * B)) ^ n * (B - 1) < δ :=
    hlim.eventually (eventually_lt_nhds hδ)
  obtain ⟨n, hn⟩ := hevent.exists
  refine ⟨n, fun b hb hbB => ?_⟩
  have hpos : 0 ≤ contract b n - 1 := by linarith [contract_gt_one hb n]
  rw [abs_of_nonneg hpos]
  exact lt_of_le_of_lt (uniform_contract_bound hb hbB n) hn

#print axioms uniform_contract_bound
#print axioms exists_uniform_contract

end PositiveSeeds
