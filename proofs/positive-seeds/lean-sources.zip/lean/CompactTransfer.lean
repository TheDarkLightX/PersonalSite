import Compiler
import ParameterStability
import ExactSeeds

/-! Positive-seed transfer of any fixed compactly valid expression and source approximant. -/
noncomputable section
open Filter Topology
namespace StrictEML

/-- Embed constant-free unary syntax as a ground term over the varying named parameter. -/
def seedTerm : ExactSeeds.SeedTerm → Term
  | .leaf => .one
  | .node a b => .node (seedTerm a) (seedTerm b)

theorem seedTerm_value (s : ExactSeeds.SeedTerm) (c : ℝ) (ρ : Nat → ℝ) :
    parameterVal (seedTerm s) (c,ρ) = s.value c := by
  induction s with
  | leaf => rfl
  | node a b ia ib => simp only [seedTerm, parameterVal, ExactSeeds.SeedTerm.value, ia, ib]

theorem seedTerm_valid (s : ExactSeeds.SeedTerm) (c : ℝ) (ρ : Nat → ℝ) :
    parameterValid (seedTerm s) (c,ρ) ↔ s.Valid c := by
  induction s with
  | leaf => rfl
  | node a b ia ib =>
    simp only [seedTerm, parameterValid, ExactSeeds.SeedTerm.Valid, ia, ib, seedTerm_value]

/-- Density plus compact stability yields one actual term uniformly approximating a fixed
seed-1 expression on K. No input-dependent selection of a term is allowed. -/
theorem compact_seed_replacement (t : Term) {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (hvalid : ∀ ρ ∈ K, Valid t ρ) {c : ℝ} (hc : 0 < c) {ε : ℝ} (hε : 0 < ε) :
    ∃ u : Term, ∀ ρ ∈ K,
      parameterValid u (c,ρ) ∧ |parameterVal u (c,ρ) - val t ρ| < ε := by
  have hev := compact_parameter_stability t hK hvalid hε
  obtain ⟨z, hz, hgood⟩ := (ExactSeeds.groundValues_dense hc).inter_nhds_nonempty hev
  obtain ⟨s,hs,hval⟩ := hz
  refine ⟨replaceOne t (seedTerm s), ?_⟩
  intro ρ hρ
  have hp := (seedTerm_valid s c ρ).mpr hs
  have hv : parameterVal (seedTerm s) (c,ρ) = z := (seedTerm_value s c ρ).trans hval
  obtain ⟨hdom,herr⟩ := hgood ρ hρ
  constructor
  · apply (parameterValid_replaceOne t (seedTerm s) (c,ρ) hp).mpr
    simpa only [hv] using hdom
  · simpa only [parameterVal_replaceOne,hv] using herr

/-- Any strictly valid source approximant transfers to every positive named seed.
The source-approximation premise is explicit; Stone-Weierstrass is not hidden in this theorem. -/
theorem transfer_source_approximation (s : Source) {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (hvalid : ∀ ρ ∈ K, s.Valid ρ) (f : (Nat → ℝ) → ℝ) {c ε : ℝ}
    (hc : 0 < c) (hε : 0 < ε)
    (happrox : ∀ ρ ∈ K, |s.val ρ - f ρ| < ε/2) :
    ∃ u : Term, ∀ ρ ∈ K,
      parameterValid u (c,ρ) ∧ |parameterVal u (c,ρ) - f ρ| < ε := by
  have hcompiled : ∀ ρ ∈ K, Valid s.compile ρ :=
    fun ρ hρ => (Source.compile_realizes s ρ (hvalid ρ hρ)).1
  obtain ⟨u,hu⟩ := compact_seed_replacement s.compile hK hcompiled hc (half_pos hε)
  refine ⟨u, fun ρ hρ => ?_⟩
  obtain ⟨hdom,herr⟩ := hu ρ hρ
  rw [(Source.compile_realizes s ρ (hvalid ρ hρ)).2] at herr
  refine ⟨hdom, ?_⟩
  have htriangle := abs_sub_le (parameterVal u (c,ρ)) (s.val ρ) (f ρ)
  have happ := happrox ρ hρ
  linarith

end StrictEML
