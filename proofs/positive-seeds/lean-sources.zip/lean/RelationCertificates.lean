import Mathlib.Tactic

/-! Strict column semantics for arbitrary finite-arity partial operations.
Columns are indexed by an arbitrary row type; finite-domain completeness
is therefore a special case, not a hidden finiteness assumption. -/
namespace CertifiedSynthesis

inductive Term (V C O : Type) (arity : O → Nat) where
  | var (v : V)
  | const (c : C)
  | app (o : O) (args : Fin (arity o) → Term V C O arity)

variable {A B V C O I : Type} {arity : O → Nat}

/-- Strict, synchronous evaluation on a witness batch. Every child and every
coordinate of the primitive must be defined. -/
inductive Evaluates
    (constant : C → A) (sem : (o : O) → (Fin (arity o) → A) → Option A)
    (input : V → I → A) : Term V C O arity → (I → A) → Prop where
  | var (v : V) : Evaluates constant sem input (.var v) (input v)
  | const (c : C) : Evaluates constant sem input (.const c) (fun _ => constant c)
  | app (o : O) (args : Fin (arity o) → Term V C O arity)
      (columns : Fin (arity o) → I → A) (out : I → A)
      (children : ∀ j, Evaluates constant sem input (args j) (columns j))
      (defined : ∀ i, sem o (fun j => columns j i) = some (out i)) :
      Evaluates constant sem input (.app o args) out

/-- Ordinary single-input strict semantics, kept independent of column semantics. -/
inductive ScalarEvaluates
    (constant : C → A) (sem : (o : O) → (Fin (arity o) → A) → Option A)
    (input : V → A) : Term V C O arity → A → Prop where
  | var (v : V) : ScalarEvaluates constant sem input (.var v) (input v)
  | const (c : C) : ScalarEvaluates constant sem input (.const c) (constant c)
  | app (o : O) (args : Fin (arity o) → Term V C O arity)
      (values : Fin (arity o) → A) (out : A)
      (children : ∀ j, ScalarEvaluates constant sem input (args j) (values j))
      (defined : sem o values = some out) :
      ScalarEvaluates constant sem input (.app o args) out

theorem column_to_scalar
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {t : Term V C O arity} {out : I → A}
    (ht : Evaluates constant sem input t out) :
    ∀ i, ScalarEvaluates constant sem (fun v => input v i) t (out i) := by
  induction ht with
  | var v => intro i; exact .var v
  | const c => intro i; exact .const c
  | app o args columns out children defined ih =>
      intro i
      exact .app o args (fun j => columns j i) (out i)
        (fun j => ih j i) (defined i)

theorem scalar_to_column
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {t : Term V C O arity} {out : I → A}
    (ht : ∀ i, ScalarEvaluates constant sem (fun v => input v i) t (out i)) :
    Evaluates constant sem input t out := by
  classical
  induction t generalizing out with
  | var v =>
      have heq : out = input v := by
        funext i
        have hi : ∀ a, ScalarEvaluates constant sem (fun v => input v i) (.var v) a → a = input v i := by
          intro a ha
          cases ha
          rfl
        exact hi _ (ht i)
      rw [heq]
      exact .var v
  | const c =>
      have heq : out = fun _ => constant c := by
        funext i
        have hi : ∀ a, ScalarEvaluates constant sem (fun v => input v i) (.const c) a → a = constant c := by
          intro a ha
          cases ha
          rfl
        exact hi _ (ht i)
      rw [heq]
      exact .const c
  | app o args ih =>
      have hex : ∀ i, ∃ values : Fin (arity o) → A,
          (∀ j, ScalarEvaluates constant sem (fun v => input v i) (args j) (values j)) ∧
          sem o values = some (out i) := by
        intro i
        cases ht i with
        | app _ _ values _ children defined => exact ⟨values, children, defined⟩
      choose values hchildren hdefined using hex
      exact .app o args (fun j i => values i j) out
        (fun j => ih j (fun i => hchildren i j)) hdefined

theorem column_iff_scalar
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {t : Term V C O arity} {out : I → A} :
    Evaluates constant sem input t out ↔
    ∀ i, ScalarEvaluates constant sem (fun v => input v i) t (out i) :=
  ⟨column_to_scalar, scalar_to_column⟩

/-- The relation certificate's complete obligations. -/
structure Invariant
    (constant : C → A) (sem : (o : O) → (Fin (arity o) → A) → Option A)
    (input : V → I → A) (R : Set (I → A)) : Prop where
  vars_mem : ∀ v, input v ∈ R
  constants : ∀ c, (fun _ => constant c) ∈ R
  closed : ∀ o (columns : Fin (arity o) → I → A) (out : I → A),
    (∀ j, columns j ∈ R) →
    (∀ i, sem o (fun j => columns j i) = some (out i)) → out ∈ R

theorem evaluation_preserves
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {R : Set (I → A)}
    (inv : Invariant constant sem input R)
    {t : Term V C O arity} {out : I → A}
    (h : Evaluates constant sem input t out) : out ∈ R := by
  induction h with
  | var v => exact inv.vars_mem v
  | const c => exact inv.constants c
  | app o args columns out children defined ih =>
      exact inv.closed o columns out ih defined

/-- Checked exclusion quantifies over every finite term, with no size bound. -/
theorem relation_obstruction
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {R : Set (I → A)}
    (inv : Invariant constant sem input R) {target : I → A}
    (excluded : target ∉ R) :
    ¬ ∃ t, Evaluates constant sem input t target := by
  rintro ⟨t, ht⟩
  exact excluded (evaluation_preserves inv ht)

/-- The canonical relation of realizable columns. -/
def Generated
    (constant : C → A) (sem : (o : O) → (Fin (arity o) → A) → Option A)
    (input : V → I → A) : Set (I → A) :=
  {out | ∃ t, Evaluates constant sem input t out}

theorem generated_invariant
    (constant : C → A) (sem : (o : O) → (Fin (arity o) → A) → Option A)
    (input : V → I → A) : Invariant constant sem input (Generated constant sem input) := by
  classical
  constructor
  · intro v
    exact ⟨.var v, .var v⟩
  · intro c
    exact ⟨.const c, .const c⟩
  · intro o columns out hcolumns hdefined
    choose args hargs using hcolumns
    exact ⟨.app o args, .app o args columns out hargs hdefined⟩

theorem generated_least
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {R : Set (I → A)}
    (inv : Invariant constant sem input R) : Generated constant sem input ⊆ R := by
  rintro out ⟨t, ht⟩
  exact evaluation_preserves inv ht

/-- Complete separation. On a full finite domain this characterizes exact synthesis. -/
theorem obstruction_iff_unrealizable
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {target : I → A} :
    (∃ R, Invariant constant sem input R ∧ target ∉ R) ↔
    ¬ ∃ t, Evaluates constant sem input t target := by
  constructor
  · rintro ⟨R, inv, excluded⟩
    exact relation_obstruction inv excluded
  · intro h
    exact ⟨Generated constant sem input, generated_invariant constant sem input, h⟩

/-- Intersection composes sound negative memories on the same witness batch. -/
theorem invariant_intersection
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → I → A} {R S : Set (I → A)}
    (hR : Invariant constant sem input R) (hS : Invariant constant sem input S) :
    Invariant constant sem input (R ∩ S) := by
  constructor
  · intro v; exact ⟨hR.vars_mem v, hS.vars_mem v⟩
  · intro c; exact ⟨hR.constants c, hS.constants c⟩
  · intro o columns out hc hd
    exact ⟨hR.closed o columns out (fun j => (hc j).1) hd,
      hS.closed o columns out (fun j => (hc j).2) hd⟩

/-- A forward strict homomorphism must preserve definedness, not merely agree
where both interpreters happen to return a value. -/
structure ForwardMap
    (constantA : C → A) (semA : (o : O) → (Fin (arity o) → A) → Option A)
    (constantB : C → B) (semB : (o : O) → (Fin (arity o) → B) → Option B)
    (h : A → B) : Prop where
  constants : ∀ c, h (constantA c) = constantB c
  operations : ∀ o xs out, semA o xs = some out →
    semB o (fun j => h (xs j)) = some (h out)

theorem evaluation_transport
    {constantA : C → A} {semA : (o : O) → (Fin (arity o) → A) → Option A}
    {constantB : C → B} {semB : (o : O) → (Fin (arity o) → B) → Option B}
    {h : A → B} (map : ForwardMap constantA semA constantB semB h)
    {input : V → I → A} {t : Term V C O arity} {out : I → A}
    (heval : Evaluates constantA semA input t out) :
    Evaluates constantB semB (fun v i => h (input v i)) t (fun i => h (out i)) := by
  induction heval with
  | var v => exact .var v
  | const c =>
      simpa only [map.constants c] using
        (Evaluates.const (constant := constantB) (sem := semB)
          (input := fun v i => h (input v i)) c)
  | app o args columns out children defined ih =>
      exact .app o args (fun j i => h (columns j i)) (fun i => h (out i))
        ih (fun i => map.operations o (fun j => columns j i) (out i) (defined i))

/-- Abstract exclusion transfers even through a noninjective representation. -/
theorem transported_obstruction
    {constantA : C → A} {semA : (o : O) → (Fin (arity o) → A) → Option A}
    {constantB : C → B} {semB : (o : O) → (Fin (arity o) → B) → Option B}
    {h : A → B} (map : ForwardMap constantA semA constantB semB h)
    {input : V → I → A} {target : I → A} {R : Set (I → B)}
    (inv : Invariant constantB semB (fun v i => h (input v i)) R)
    (excluded : (fun i => h (target i)) ∉ R) :
    ¬ ∃ t, Evaluates constantA semA input t target := by
  rintro ⟨t, ht⟩
  exact excluded (evaluation_preserves inv (evaluation_transport map ht))

variable {K : Type}

/-- A cost algebra can count trees, depth, or any monotone constructor objective. -/
def Term.cost (variableCost : V → K) (constantCost : C → K)
    (combine : (o : O) → (Fin (arity o) → K) → K) : Term V C O arity → K
  | .var v => variableCost v
  | .const c => constantCost c
  | .app o args => combine o (fun j => (args j).cost variableCost constantCost combine)

/-- Bellman inequalities are all-term lower-bound certificates. -/
theorem potential_lower_bound [Preorder K]
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → A} {potential : A → K}
    {variableCost : V → K} {constantCost : C → K}
    {combine : (o : O) → (Fin (arity o) → K) → K}
    (hvar : ∀ v, potential (input v) ≤ variableCost v)
    (hconst : ∀ c, potential (constant c) ≤ constantCost c)
    (hstep : ∀ o values out, sem o values = some out →
      potential out ≤ combine o (fun j => potential (values j)))
    (hmono : ∀ o x y, (∀ j, x j ≤ y j) → combine o x ≤ combine o y)
    {t : Term V C O arity} {out : A}
    (ht : ScalarEvaluates constant sem input t out) :
    potential out ≤ t.cost variableCost constantCost combine := by
  induction ht with
  | var v => exact hvar v
  | const c => exact hconst c
  | app o args values out children defined ih =>
      exact le_trans (hstep o values out defined)
        (hmono o _ _ ih)

/-- An attaining witness plus the lower-bound certificate proves optimality. -/
theorem attaining_witness_optimal [Preorder K]
    {constant : C → A} {sem : (o : O) → (Fin (arity o) → A) → Option A}
    {input : V → A} {potential : A → K}
    {variableCost : V → K} {constantCost : C → K}
    {combine : (o : O) → (Fin (arity o) → K) → K}
    (hvar : ∀ v, potential (input v) ≤ variableCost v)
    (hconst : ∀ c, potential (constant c) ≤ constantCost c)
    (hstep : ∀ o values out, sem o values = some out →
      potential out ≤ combine o (fun j => potential (values j)))
    (hmono : ∀ o x y, (∀ j, x j ≤ y j) → combine o x ≤ combine o y)
    {witness candidate : Term V C O arity} {out : A}
    (hwitness : ScalarEvaluates constant sem input witness out)
    (attains : witness.cost variableCost constantCost combine = potential out)
    (hcandidate : ScalarEvaluates constant sem input candidate out) :
    ScalarEvaluates constant sem input witness out ∧
      witness.cost variableCost constantCost combine ≤
        candidate.cost variableCost constantCost combine := by
  constructor
  · exact hwitness
  rw [attains]
  exact potential_lower_bound hvar hconst hstep hmono hcandidate

#print axioms evaluation_preserves
#print axioms column_iff_scalar
#print axioms relation_obstruction
#print axioms generated_invariant
#print axioms generated_least
#print axioms obstruction_iff_unrealizable
#print axioms invariant_intersection
#print axioms evaluation_transport
#print axioms transported_obstruction
#print axioms potential_lower_bound
#print axioms attaining_witness_optimal

end CertifiedSynthesis
