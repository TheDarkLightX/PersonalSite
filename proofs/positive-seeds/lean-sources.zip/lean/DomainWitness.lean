import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

/-! A structural domain obstruction: strict EML evaluation of any nonleaf tree
requires one fixed leaf to be positive throughout its domain. -/
noncomputable section
namespace DomainWitness

inductive Tree (C : Type*) where
  | constant : C → Tree C
  | var : Nat → Tree C
  | node : Tree C → Tree C → Tree C

variable {C : Type*}

def value (κ : C → ℝ) : Tree C → (Nat → ℝ) → ℝ
  | .constant c, _ => κ c
  | .var n, ρ => ρ n
  | .node a b, ρ => Real.exp (value κ a ρ) - Real.log (value κ b ρ)

def Valid (κ : C → ℝ) : Tree C → (Nat → ℝ) → Prop
  | .constant _, _ => True
  | .var _, _ => True
  | .node a b, ρ => Valid κ a ρ ∧ Valid κ b ρ ∧ 0 < value κ b ρ

def rightLeaf : Tree C → C ⊕ Nat
  | .constant c => .inl c
  | .var n => .inr n
  | .node _ b => rightLeaf b

def leafValue (κ : C → ℝ) (ρ : Nat → ℝ) : C ⊕ Nat → ℝ
  | .inl c => κ c
  | .inr n => ρ n

/-- The selected leaf depends on syntax alone, not on the input environment. -/
theorem positive_rightLeaf (a b : Tree C) (κ : C → ℝ) (ρ : Nat → ℝ)
    (h : Valid κ (.node a b) ρ) : 0 < leafValue κ ρ (rightLeaf b) := by
  induction b generalizing a with
  | constant c => exact h.2.2
  | var n => exact h.2.2
  | node b₁ b₂ _ ih => exact ih b₁ h.2.1

/-- With no positive named constants, every nonleaf term valid on a nonempty
input set requires a single coordinate positive on the entire set. -/
theorem uniform_positive_coordinate (a b : Tree C) (κ : C → ℝ)
    (hκ : ∀ c, κ c ≤ 0) {D : Set (Nat → ℝ)} (hD : D.Nonempty)
    (hv : ∀ ρ ∈ D, Valid κ (.node a b) ρ) :
    ∃ n : Nat, ∀ ρ ∈ D, 0 < ρ n := by
  have hp (ρ) (hρ : ρ ∈ D) := positive_rightLeaf a b κ ρ (hv ρ hρ)
  cases he : rightLeaf b with
  | inl c =>
      obtain ⟨ρ, hρ⟩ := hD
      have h := hp ρ hρ
      simp only [he, leafValue] at h
      exact False.elim ((not_lt_of_ge (hκ c)) h)
  | inr n =>
      refine ⟨n, fun ρ hρ => ?_⟩
      simpa only [he, leafValue] using hp ρ hρ

/-- A pointwise choice of positive coordinate does not suffice: the witness
coordinate must be the same at every input. -/
theorem excludes_all_composites (κ : C → ℝ) (hκ : ∀ c, κ c ≤ 0)
    {D : Set (Nat → ℝ)} (hD : D.Nonempty)
    (hneg : ∀ n : Nat, ∃ ρ ∈ D, ρ n ≤ 0) (a b : Tree C) :
    ¬ (∀ ρ ∈ D, Valid κ (.node a b) ρ) := by
  intro hv
  obtain ⟨n, hn⟩ := uniform_positive_coordinate a b κ hκ hD hv
  obtain ⟨ρ, hρ, hρn⟩ := hneg n
  exact (not_lt_of_ge hρn) (hn ρ hρ)

end DomainWitness
