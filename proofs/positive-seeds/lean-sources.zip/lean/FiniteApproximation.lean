import Approximation

/-! Finite-dimensional specialization with no hidden extra input variables. -/
noncomputable section
open Set Topology
namespace StrictEML

def extendEnv (n : Nat) (c : ℝ) (x : Fin n → ℝ) : Nat → ℝ :=
  fun i => if h : i < n then x ⟨i,h⟩ else c

def restrictEnv (n : Nat) (ρ : Nat → ℝ) : Fin n → ℝ := fun i => ρ i.val

theorem continuous_extendEnv (n : Nat) (c : ℝ) : Continuous (extendEnv n c) := by
  apply continuous_pi
  intro i
  by_cases h : i < n
  · simpa only [extendEnv,dif_pos h] using (continuous_apply (⟨i,h⟩ : Fin n))
  · simpa only [extendEnv,dif_neg h] using (continuous_const : Continuous (fun _ : Fin n → ℝ => c))

theorem continuous_restrictEnv (n : Nat) : Continuous (restrictEnv n) := by
  exact continuous_pi (fun i => continuous_apply i.val)

@[simp] theorem restrict_extendEnv (n : Nat) (c : ℝ) (x : Fin n → ℝ) :
    restrictEnv n (extendEnv n c x) = x := by
  funext i
  simp [restrictEnv,extendEnv,i.isLt]

def truncateVars : Term → Nat → Term
  | .one, _ => .one
  | .var i, n => if i < n then .var i else .one
  | .node a b, n => .node (truncateVars a n) (truncateVars b n)

def VarsBelow : Nat → Term → Prop
  | _, .one => True
  | n, .var i => i < n
  | n, .node a b => VarsBelow n a ∧ VarsBelow n b

theorem truncateVars_below (t : Term) (n : Nat) : VarsBelow n (truncateVars t n) := by
  induction t with
  | one => trivial
  | var i => by_cases h : i < n <;> simp [truncateVars,VarsBelow,h]
  | node a b ia ib => exact ⟨ia,ib⟩

theorem truncateVars_value (t : Term) (n : Nat) (c : ℝ) (x : Fin n → ℝ) :
    parameterVal (truncateVars t n) (c,extendEnv n c x) =
    parameterVal t (c,extendEnv n c x) := by
  induction t with
  | one => rfl
  | var i => by_cases h : i < n <;> simp [truncateVars,parameterVal,extendEnv,h]
  | node a b ia ib => simp only [truncateVars,parameterVal,ia,ib]

theorem truncateVars_valid (t : Term) (n : Nat) (c : ℝ) (x : Fin n → ℝ) :
    parameterValid (truncateVars t n) (c,extendEnv n c x) ↔
    parameterValid t (c,extendEnv n c x) := by
  induction t with
  | one => rfl
  | var i => by_cases h : i < n <;> simp [truncateVars,parameterValid,h]
  | node a b ia ib => simp only [truncateVars,parameterValid,ia,ib,truncateVars_value]

/-- For every finite dimension, every positive seed gives uniform approximation on compact K
by a term using only that seed and the declared n variables, valid on an open neighborhood. -/
theorem finite_dimensional_approximation (n : Nat) {K : Set (Fin n → ℝ)} (hK : IsCompact K)
    (f : C(K,ℝ)) {c ε : ℝ} (hc : 0 < c) (hε : 0 < ε) :
    ∃ (u : Term) (U : Set (Fin n → ℝ)), VarsBelow n u ∧ IsOpen U ∧ K ⊆ U ∧
      (∀ x ∈ U, parameterValid u (c,extendEnv n c x)) ∧
      ∀ x : K, |parameterVal u (c,extendEnv n c x.val) - f x| < ε := by
  let K' : Set (Nat → ℝ) := extendEnv n c '' K
  have hK' : IsCompact K' := hK.image (continuous_extendEnv n c)
  let back : K' → K := fun x => ⟨restrictEnv n x.val, by
    obtain ⟨y,hy,hxy⟩ := x.property
    rw [←hxy,restrict_extendEnv]
    exact hy⟩
  have hb : Continuous back := by
    exact ((continuous_restrictEnv n).comp continuous_subtype_val).subtype_mk _
  let g : C(K',ℝ) := f.comp ⟨back,hb⟩
  obtain ⟨t,ht⟩ := positive_seed_compact_approximation hK' g hc hε
  let u := truncateVars t n
  let U : Set (Fin n → ℝ) := {x | parameterValid u (c,extendEnv n c x)}
  refine ⟨u,U,truncateVars_below t n,?_,?_,?_,?_⟩
  · exact (parameter_domain_open u).preimage (continuous_const.prodMk (continuous_extendEnv n c))
  · intro x hx
    exact (truncateVars_valid t n c x).mpr (ht ⟨extendEnv n c x,⟨x,hx,rfl⟩⟩).1
  · intro x hx; exact hx
  · intro x
    have hh := (ht ⟨extendEnv n c x.val,⟨x.val,x.property,rfl⟩⟩).2
    rw [truncateVars_value]
    simpa [g,back] using hh

end StrictEML
