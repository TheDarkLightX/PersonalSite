import Arithmetic

/-! A strict-domain impossibility result for any family of named constants and variables. -/
noncomputable section
namespace StrictEML

inductive LeafTerm (α : Type) where
  | leaf : α → LeafTerm α
  | node : LeafTerm α → LeafTerm α → LeafTerm α

namespace LeafTerm

def value {α : Type} : LeafTerm α → (α → ℝ) → ℝ
  | .leaf a, ρ => ρ a
  | .node a b, ρ => Real.exp (value a ρ) - Real.log (value b ρ)

def Valid {α : Type} : LeafTerm α → (α → ℝ) → Prop
  | .leaf _, _ => True
  | .node a b, ρ => Valid a ρ ∧ Valid b ρ ∧ 0 < value b ρ

/-- No strictly valid composite expression exists when every leaf has nonpositive value. -/
theorem valid_is_leaf {α : Type} (t : LeafTerm α) (ρ : α → ℝ)
    (hρ : ∀ a, ρ a ≤ 0) (ht : Valid t ρ) : ∃ a, t = .leaf a := by
  induction t with
  | leaf a => exact ⟨a,rfl⟩
  | node a b ia ib =>
    obtain ⟨v,hv⟩ := ib ht.2.1
    subst b
    exact False.elim ((not_lt_of_ge (hρ v)) ht.2.2)

theorem valid_value_nonpositive {α : Type} (t : LeafTerm α) (ρ : α → ℝ)
    (hρ : ∀ a, ρ a ≤ 0) (ht : Valid t ρ) : value t ρ ≤ 0 := by
  obtain ⟨a,rfl⟩ := valid_is_leaf t ρ hρ ht
  exact hρ a

/-- At such an input, no defined term approximates the constant 1 with error strictly below 1. -/
theorem constant_one_error {α : Type} (t : LeafTerm α) (ρ : α → ℝ)
    (hρ : ∀ a, ρ a ≤ 0) (ht : Valid t ρ) : 1 ≤ |value t ρ - 1| := by
  have hn := valid_value_nonpositive t ρ hρ ht
  rw [abs_of_nonpos (by linarith)]
  linarith

/-- Specialization to any declared constant family and arbitrary many variables at the origin. -/
theorem origin_obstruction {κ ι : Type} (constants : κ → ℝ)
    (hc : ∀ c, constants c ≤ 0) (t : LeafTerm (κ ⊕ ι))
    (ht : Valid t (Sum.elim constants (fun _ => 0))) :
    1 ≤ |value t (Sum.elim constants (fun _ => 0)) - 1| := by
  apply constant_one_error t _ _ ht
  intro a
  cases a with
  | inl c => exact hc c
  | inr i => exact le_rfl

/-- Minimal domain-erasure mutant: totalized `Real.log 0 = 0` falsely supplies 1 from seed 0. -/
theorem zero_seed_domain_erasure_counterexample :
    value (.node (.leaf ()) (.leaf ())) (fun _ : Unit => (0:ℝ)) = 1 ∧
    ¬ Valid (.node (.leaf ()) (.leaf ())) (fun _ : Unit => (0:ℝ)) := by
  norm_num [value, Valid]

end LeafTerm
end StrictEML
