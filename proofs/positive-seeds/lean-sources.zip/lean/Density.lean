import Arithmetic
import Mathlib.Topology.Algebra.Order.Archimedean
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Topology.Order.MonotoneConvergence
import Mathlib.Topology.Sequences
import Mathlib.Tactic

open Set Filter Topology

namespace PositiveSeeds

/-- Closure under the strict real EML operation. -/
def Stable (K : Set ℝ) : Prop :=
  ∀ a ∈ K, ∀ b ∈ K, 0 < b → Real.exp a - Real.log b ∈ K

lemma self_growth {t : ℝ} (ht : 0 < t) :
    t + 1 ≤ Real.exp t - Real.log t := by
  have h1 : 2 ≤ Real.exp 1 := by
    have := Real.add_one_le_exp (1 : ℝ)
    linarith
  have h2 : t ≤ Real.exp (t - 1) := by
    have := Real.add_one_le_exp (t - 1)
    linarith
  have h3 : 2 * t ≤ Real.exp t := by
    calc
      2 * t ≤ Real.exp 1 * Real.exp (t - 1) :=
        mul_le_mul h1 h2 ht.le (Real.exp_pos 1).le
      _ = Real.exp t := by rw [← Real.exp_add]; congr 1; ring
  have h4 := Real.log_le_sub_one_of_pos ht
  linarith

/-- A constant-free unary EML context with four primitive nodes. -/
noncomputable def step (b : ℝ) : ℝ :=
  Real.exp (Real.exp b - Real.log (Real.exp (Real.exp b - Real.log b) - Real.log b)) - Real.log b

lemma exp_ge_twice {b : ℝ} (hb : 0 < b) : 2 * b ≤ Real.exp b := by
  have h1 : 2 ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  have h2 : b ≤ Real.exp (b - 1) := by linarith [Real.add_one_le_exp (b - 1)]
  calc
    2 * b ≤ Real.exp 1 * Real.exp (b - 1) :=
      mul_le_mul h1 h2 hb.le (Real.exp_pos 1).le
    _ = Real.exp b := by rw [← Real.exp_add]; congr 1; ring

lemma double_exp_ge {b : ℝ} (hb : 0 < b) : 4 * b ^ 2 ≤ Real.exp (Real.exp b) := by
  have he := exp_ge_twice hb
  have hsq : (2 * b) ^ 2 ≤ (Real.exp b) ^ 2 := by nlinarith [Real.exp_pos b]
  calc
    4 * b ^ 2 = (2 * b) ^ 2 := by ring
    _ ≤ (Real.exp b) ^ 2 := hsq
    _ = Real.exp (2 * b) := by rw [two_mul, Real.exp_add]; ring
    _ ≤ Real.exp (Real.exp b) := Real.exp_le_exp.mpr he

lemma step_den_pos {b : ℝ} (hb : 1 < b) :
    0 < Real.exp (Real.exp b) - b * Real.log b := by
  have hp : 0 < b := by linarith
  have hh := double_exp_ge hp
  have hl := Real.log_le_sub_one_of_pos hp
  nlinarith [mul_le_mul_of_nonneg_left hl hp.le]

lemma step_inner_pos {b : ℝ} (hb : 1 < b) :
    0 < Real.exp (Real.exp b - Real.log b) - Real.log b := by
  have hp : 0 < b := by linarith
  rw [Real.exp_sub, Real.exp_log hp]
  have hd := step_den_pos hb
  have : Real.log b < Real.exp (Real.exp b) / b := (lt_div_iff₀ hp).mpr (by nlinarith)
  linarith

lemma step_identity {b : ℝ} (hb : 1 < b) :
    step b = b - Real.log b +
      b ^ 2 * Real.log b / (Real.exp (Real.exp b) - b * Real.log b) := by
  have hp : 0 < b := by linarith
  have hi := step_inner_pos hb
  have hd := step_den_pos hb
  unfold step
  rw [Real.exp_sub, Real.exp_log hi, Real.exp_sub, Real.exp_log hp]
  field_simp
  ring

lemma step_bounds {b : ℝ} (hb : 1 < b) :
    1 < step b ∧ step b < b - (2 / 3 : ℝ) * Real.log b := by
  have hp : 0 < b := by linarith
  have hl : 0 < Real.log b := Real.log_pos hb
  have hlog := Real.log_le_sub_one_of_pos hp
  have hh := double_exp_ge hp
  have hden : 3 * b ^ 2 < Real.exp (Real.exp b) - b * Real.log b := by
    nlinarith [mul_le_mul_of_nonneg_left hlog hp.le]
  have hd := step_den_pos hb
  have hcorpos : 0 < b ^ 2 * Real.log b / (Real.exp (Real.exp b) - b * Real.log b) :=
    div_pos (mul_pos (sq_pos_of_pos hp) hl) hd
  have hcorlt : b ^ 2 * Real.log b / (Real.exp (Real.exp b) - b * Real.log b) < Real.log b / 3 := by
    apply (div_lt_iff₀ hd).mpr
    have := mul_lt_mul_of_pos_right hden hl
    nlinarith
  rw [step_identity hb]
  constructor <;> linarith

noncomputable def contract (b : ℝ) : ℕ → ℝ
  | 0 => b
  | n+1 => step (contract b n)

lemma contract_gt_one {b : ℝ} (hb : 1 < b) (n : ℕ) : 1 < contract b n := by
  induction n with
  | zero => exact hb
  | succ n ih => exact (step_bounds ih).1

lemma contract_antitone {b : ℝ} (hb : 1 < b) : Antitone (contract b) := by
  apply antitone_nat_of_succ_le
  intro n
  have hn := contract_gt_one hb n
  have hstep := (step_bounds hn).2
  have hl := Real.log_pos hn
  dsimp [contract]
  linarith

/-- The four-node context converges to 1 from every initial b > 1. -/
theorem contract_tendsto_one {b : ℝ} (hb : 1 < b) :
    Tendsto (contract b) atTop (𝓝 1) := by
  have hbound : BddBelow (Set.range (contract b)) := ⟨1, by
    rintro x ⟨n, rfl⟩
    exact (contract_gt_one hb n).le⟩
  have hlim := tendsto_atTop_ciInf (contract_antitone hb) hbound
  have hinf : 1 ≤ ⨅ n, contract b n := le_ciInf (fun n => (contract_gt_one hb n).le)
  have hpos : 0 < ⨅ n, contract b n := lt_of_lt_of_le zero_lt_one hinf
  have hlog := (Real.continuousAt_log (ne_of_gt hpos)).tendsto.comp hlim
  have hsub := hlim.sub (hlog.const_mul (2 / 3 : ℝ))
  have hshift := hlim.comp (tendsto_add_atTop_nat 1)
  have hineq : (⨅ n, contract b n) ≤ (⨅ n, contract b n) - (2 / 3 : ℝ) * Real.log (⨅ n, contract b n) := by
    apply le_of_tendsto_of_tendsto hshift hsub
    filter_upwards [] with n
    exact (step_bounds (contract_gt_one hb n)).2.le
  have hz : Real.log (⨅ n, contract b n) = 0 := by
    have := Real.log_nonneg hinf
    linarith
  have hone : (⨅ n, contract b n) = 1 := by
    have hexp := congrArg Real.exp hz
    simpa [Real.exp_log hpos] using hexp
  simpa [hone] using hlim

lemma step_mem {K : Set ℝ} (hK : Stable K) {b : ℝ} (hmem : b ∈ K) (hb : 1 < b) :
    step b ∈ K := by
  have hp : 0 < b := by linarith
  exact hK _ (hK _ hmem _ (hK _ (hK _ hmem _ hmem hp) _ hmem hp) (step_inner_pos hb)) _ hmem hp

lemma contract_mem {K : Set ℝ} (hK : Stable K) {b : ℝ} (hmem : b ∈ K)
    (hb : 1 < b) (n : ℕ) : contract b n ∈ K := by
  induction n with
  | zero => exact hmem
  | succ n ih => exact step_mem hK ih (contract_gt_one hb n)

/-- Direct constructive proof: no closure-log extraction is needed. -/
theorem one_mem_of_closed_stable_constructive {K : Set ℝ} (hclosed : IsClosed K) (hK : Stable K)
    {c : ℝ} (hmem : c ∈ K) (hc : 0 < c) : (1 : ℝ) ∈ K := by
  let b := Real.exp c - Real.log c
  have hb : 1 < b := by dsimp [b]; linarith [self_growth hc]
  have hbm : b ∈ K := hK _ hmem _ hmem hc
  exact hclosed.mem_of_tendsto (contract_tendsto_one hb)
    (Eventually.of_forall (contract_mem hK hbm hb))

#print axioms contract_tendsto_one
#print axioms one_mem_of_closed_stable_constructive

/-- Partial-operation stability passes to ordinary closure inside its open domain. -/
theorem stable_closure {K : Set ℝ} (hK : Stable K) : Stable (closure K) := by
  intro a ha b hb hbp
  obtain ⟨u, hum, hut⟩ := mem_closure_iff_seq_limit.mp ha
  obtain ⟨v, hvm, hvt⟩ := mem_closure_iff_seq_limit.mp hb
  have hvp : ∀ᶠ n in atTop, 0 < v n := hvt.eventually (eventually_gt_nhds hbp)
  apply isClosed_closure.mem_of_tendsto
    ((Real.continuous_exp.continuousAt.tendsto.comp hut).sub
      ((Real.continuousAt_log (ne_of_gt hbp)).tendsto.comp hvt))
  filter_upwards [hvp] with n hn
  exact subset_closure (hK _ (hum n) _ (hvm n) hn)

/-- Every closed strict-EML-stable real set containing a positive element is all of R. -/
theorem closed_stable_eq_univ {K : Set ℝ} (hclosed : IsClosed K) (hK : Stable K)
    {c : ℝ} (hmem : c ∈ K) (hc : 0 < c) : K = Set.univ := by
  have hone := one_mem_of_closed_stable_constructive hclosed hK hmem hc
  have hrat : Set.range (fun q : ℚ => (q : ℝ)) ⊆ K := by
    rintro x ⟨q, rfl⟩
    exact StrictEML.stable_one_rat_mem K hone hK q
  have hdense : Dense K := Rat.denseRange_cast.mono hrat
  exact hclosed.closure_eq ▸ hdense.closure_eq

/-- Positive-seed density, expressed independently of a particular syntax encoding. -/
theorem closure_eq_univ {K : Set ℝ} (hK : Stable K)
    {c : ℝ} (hmem : c ∈ K) (hc : 0 < c) : closure K = Set.univ :=
  closed_stable_eq_univ isClosed_closure (stable_closure hK) (subset_closure hmem) hc

#print axioms closure_eq_univ

/-- A quantitative contraction bound on any bounded interval [1,B]. -/
lemma step_error_bound {b B : ℝ} (hb : 1 < b) (hB : b ≤ B) :
    step b - 1 ≤ (1 - 2 / (3 * B)) * (b - 1) := by
  have hp : 0 < b := by linarith
  have hBp : 0 < B := by linarith
  have hl := Real.log_pos hb
  have hlo := Real.one_sub_inv_le_log_of_pos hp
  have hh := mul_le_mul_of_nonneg_left hlo hp.le
  have hmul : b - 1 ≤ b * Real.log b := by
    simpa [mul_sub, mul_inv_cancel₀ (ne_of_gt hp)] using hh
  have hlogB : (b - 1) / B ≤ Real.log b := by
    apply (div_le_iff₀ hBp).mpr
    nlinarith
  have hstep := (step_bounds hb).2
  have heq : (1 - 2 / (3 * B)) * (b - 1) =
      b - 1 - (2 / 3 : ℝ) * ((b - 1) / B) := by field_simp
  rw [heq]
  linarith

/-- Explicit geometric error rate for the four-node ground-context iteration. -/
theorem contract_error_bound {b : ℝ} (hb : 1 < b) (n : ℕ) :
    contract b n - 1 ≤ (1 - 2 / (3 * b)) ^ n * (b - 1) := by
  have hp : 0 < b := by linarith
  have hq : 0 ≤ 1 - 2 / (3 * b) := by
    have hden : 0 < 3 * b := by positivity
    have hd : 2 / (3 * b) ≤ 1 := (div_le_one hden).mpr (by linarith)
    linarith
  induction n with
  | zero => simp [contract]
  | succ n ih =>
    have hbn : contract b n ≤ b := by
      simpa [contract] using contract_antitone hb (Nat.zero_le n)
    have hs := step_error_bound (contract_gt_one hb n) hbn
    have hm := mul_le_mul_of_nonneg_left ih hq
    simp only [contract, pow_succ]
    nlinarith

#print axioms contract_error_bound

/-- Closed scalar invariants are exactly R and the nonpositive closed sets. -/
theorem closed_stable_iff {K : Set ℝ} (hclosed : IsClosed K) :
    Stable K ↔ K = Set.univ ∨ K ⊆ Set.Iic 0 := by
  constructor
  · intro hK
    by_cases hpos : ∃ c ∈ K, 0 < c
    · obtain ⟨c, hcm, hcp⟩ := hpos
      exact Or.inl (closed_stable_eq_univ hclosed hK hcm hcp)
    · right
      intro c hc
      exact le_of_not_gt (fun hp => hpos ⟨c, hc, hp⟩)
  · rintro (rfl | hneg)
    · intro a ha b hb hbp
      exact Set.mem_univ _
    · intro a ha b hb hbp
      exact False.elim (not_lt_of_ge (hneg hb) hbp)

/-- Every finite bootstrap iterate remains strictly above 1. -/
theorem bootstrap_ne_one {c : ℝ} (hc : 0 < c) (n : ℕ) :
    contract (Real.exp c - Real.log c) n ≠ 1 := by
  have hb : 1 < Real.exp c - Real.log c := by linarith [self_growth hc]
  exact ne_of_gt (contract_gt_one hb n)

#print axioms closed_stable_iff
#print axioms bootstrap_ne_one

end PositiveSeeds
