import Arithmetic

/-! The whole strict exp/log/arithmetic language compiles to one EML constructor. -/
noncomputable section
namespace StrictEML

@[simp] theorem validE_iff (a : Term) (ρ : Nat → ℝ) : Valid (E a) ρ ↔ Valid a ρ := by
  simp [E, Valid, val]

@[simp] theorem validL_iff (a : Term) (ρ : Nat → ℝ) :
    Valid (L a) ρ ↔ Valid a ρ ∧ 0 < val a ρ := by
  simp [L, E, Valid, val, Real.exp_pos]

@[simp] theorem validP_iff (a : Term) (ρ : Nat → ℝ) : Valid (P a) ρ ↔ Valid a ρ := by
  constructor
  · intro h; exact h.1
  · intro h; exact (repP ⟨h,rfl⟩).1

@[simp] theorem validH_iff (a : Term) (ρ : Nat → ℝ) : Valid (H a) ρ ↔ Valid a ρ := by
  constructor
  · intro h; exact (validP_iff a ρ).mp ((validL_iff (P a) ρ).mp h).1
  · intro h; exact (repH ⟨h,rfl⟩).1

@[simp] theorem validA_iff (a b : Term) (ρ : Nat → ℝ) :
    Valid (A a b) ρ ↔ Valid a ρ ∧ Valid b ρ := by
  constructor
  · intro h; exact ⟨h.2.1.1.2.1.1, h.1⟩
  · rintro ⟨ha,hb⟩; exact (repA ⟨ha,rfl⟩ ⟨hb,rfl⟩).1

@[simp] theorem validS_iff (a b : Term) (ρ : Nat → ℝ) :
    Valid (S a b) ρ ↔ Valid a ρ ∧ Valid b ρ := by
  constructor
  · intro h; exact ⟨h.2.1.1.2.1.1, (validH_iff b ρ).mp h.1⟩
  · rintro ⟨ha,hb⟩; exact (repS ⟨ha,rfl⟩ ⟨hb,rfl⟩).1

inductive Source where
  | one : Source
  | var : Nat → Source
  | exp : Source → Source
  | log : Source → Source
  | add : Source → Source → Source
  | sub : Source → Source → Source
  | mul : Source → Source → Source
  | div : Source → Source → Source
  deriving DecidableEq

namespace Source

def val : Source → (Nat → ℝ) → ℝ
  | .one, _ => 1
  | .var n, ρ => ρ n
  | .exp a, ρ => Real.exp (val a ρ)
  | .log a, ρ => Real.log (val a ρ)
  | .add a b, ρ => val a ρ + val b ρ
  | .sub a b, ρ => val a ρ - val b ρ
  | .mul a b, ρ => val a ρ * val b ρ
  | .div a b, ρ => val a ρ / val b ρ

def Valid : Source → (Nat → ℝ) → Prop
  | .one, _ => True
  | .var _, _ => True
  | .exp a, ρ => Valid a ρ
  | .log a, ρ => Valid a ρ ∧ 0 < val a ρ
  | .add a b, ρ => Valid a ρ ∧ Valid b ρ
  | .sub a b, ρ => Valid a ρ ∧ Valid b ρ
  | .mul a b, ρ => Valid a ρ ∧ Valid b ρ
  | .div a b, ρ => Valid a ρ ∧ Valid b ρ ∧ val b ρ ≠ 0

def compile : Source → Term
  | .one => .one
  | .var n => .var n
  | .exp a => E (compile a)
  | .log a => L (compile a)
  | .add a b => A (compile a) (compile b)
  | .sub a b => S (compile a) (compile b)
  | .mul a b => M (compile a) (compile b)
  | .div a b => D (compile a) (compile b)

/-- Every strictly defined source program has a strictly defined, exactly equal EML program. -/
theorem compile_realizes (s : Source) (ρ : Nat → ℝ) (h : Valid s ρ) :
    Realizes (compile s) ρ (val s ρ) := by
  induction s with
  | one => exact repOne ρ
  | var n => exact repVar ρ n
  | exp a ih => exact repE (ih h)
  | log a ih => exact repL (ih h.1) h.2
  | add a b ia ib => exact repA (ia h.1) (ib h.2)
  | sub a b ia ib => exact repS (ia h.1) (ib h.2)
  | mul a b ia ib => exact repM (ia h.1) (ib h.2)
  | div a b ia ib => exact repD (ia h.1) (ib h.2.1) h.2.2

/-- Compilation preserves the natural domain in both directions, not only the values. -/
theorem compile_valid_iff (s : Source) (ρ : Nat → ℝ) :
    StrictEML.Valid (compile s) ρ ↔ Valid s ρ := by
  induction s with
  | one => rfl
  | var n => rfl
  | exp a ih => simpa only [compile, validE_iff] using ih
  | log a ih =>
    change StrictEML.Valid (L (compile a)) ρ ↔ Valid a ρ ∧ 0 < val a ρ
    rw [validL_iff, ih]
    constructor
    · rintro ⟨ha,hp⟩
      rw [(compile_realizes a ρ ha).2] at hp
      exact ⟨ha,hp⟩
    · rintro ⟨ha,hp⟩
      exact ⟨ha, by rwa [(compile_realizes a ρ ha).2]⟩
  | add a b ia ib => simp only [compile, Valid, validA_iff, ia, ib]
  | sub a b ia ib => simp only [compile, Valid, validS_iff, ia, ib]
  | mul a b ia ib => simp only [compile, Valid, validM_iff, ia, ib]
  | div a b ia ib =>
    change StrictEML.Valid (D (compile a) (compile b)) ρ ↔
      Valid a ρ ∧ Valid b ρ ∧ val b ρ ≠ 0
    rw [validD_iff, ia, ib]
    constructor
    · rintro ⟨ha,hb,hp⟩
      rw [(compile_realizes b ρ hb).2] at hp
      exact ⟨ha,hb,hp⟩
    · rintro ⟨ha,hb,hp⟩
      exact ⟨ha,hb, by rwa [(compile_realizes b ρ hb).2]⟩

end Source
end StrictEML
