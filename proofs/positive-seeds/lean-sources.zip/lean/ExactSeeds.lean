import Mathlib.Analysis.Analytic.IsolatedZeros
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic
import Mathlib.Topology.Bases
import Mathlib.Topology.Sequences
import Mathlib.Tactic.DeriveCountable
import Mathlib.Tactic.Tauto
import Density

/-! Constant-free unary strict EML terms. `value` uses Mathlib's total functions,
but every semantic statement is restricted by the recursive predicate `Valid`.
-/
noncomputable section
open Set Filter Topology
namespace ExactSeeds

inductive SeedTerm where
  | leaf : SeedTerm
  | node : SeedTerm → SeedTerm → SeedTerm
  deriving Countable

namespace SeedTerm

def value : SeedTerm → ℝ → ℝ
  | leaf, x => x
  | node a b, x => Real.exp (value a x) - Real.log (value b x)

def Valid : SeedTerm → ℝ → Prop
  | leaf, _ => True
  | node a b, x => Valid a x ∧ Valid b x ∧ 0 < value b x

theorem analyticAt_value (t : SeedTerm) {x : ℝ} (hx : Valid t x) :
    AnalyticAt ℝ (value t) x := by
  induction t with
  | leaf => exact analyticAt_id
  | node a b ha hb =>
      exact (ha hx.1).rexp.sub ((hb hx.2.1).log hx.2.2)

theorem isOpen_valid (t : SeedTerm) : IsOpen {x | Valid t x} := by
  induction t with
  | leaf => exact isOpen_univ
  | node a b ha hb =>
      rw [isOpen_iff_mem_nhds]
      intro x hx
      have h₁ := ha.mem_nhds hx.1
      have h₂ := hb.mem_nhds hx.2.1
      have h₃ := (analyticAt_value b hx.2.1).continuousAt.eventually (eventually_gt_nhds hx.2.2)
      filter_upwards [h₁, h₂, h₃] with y hya hyb hypos
      exact ⟨hya, hyb, hypos⟩

def subst : SeedTerm → SeedTerm → SeedTerm
  | leaf, s => s
  | node a b, s => node (subst a s) (subst b s)

theorem value_subst (t s : SeedTerm) (x : ℝ) :
    value (subst t s) x = value t (value s x) := by
  induction t with
  | leaf => rfl
  | node a b ha hb => simp only [subst, value, ha, hb]

theorem valid_subst (t s : SeedTerm) (x : ℝ) :
    Valid (subst t s) x ↔ Valid s x ∧ Valid t (value s x) := by
  induction t with
  | leaf => simp [subst, Valid]
  | node a b ha hb =>
      simp only [subst, Valid, ha, hb, value_subst]
      tauto

end SeedTerm

open SeedTerm

def LocalOne (t : SeedTerm) : Prop :=
  ∃ x, Valid t x ∧ ∀ᶠ y in 𝓝 x, value t y = 1

def ExactSet (t : SeedTerm) : Set ℝ := {x | Valid t x ∧ value t x = 1}

theorem localOne_iff_interval (t : SeedTerm) : LocalOne t ↔
    ∃ a b : ℝ, a < b ∧ ∀ x ∈ Set.Ioo a b, Valid t x ∧ value t x = 1 := by
  constructor
  · rintro ⟨x, hx, hval⟩
    have hn : ExactSet t ∈ 𝓝 x := by
      filter_upwards [(isOpen_valid t).mem_nhds hx, hval] with y hyv hye
      exact ⟨hyv, hye⟩
    obtain ⟨a, b, hxab, hab⟩ := mem_nhds_iff_exists_Ioo_subset.mp hn
    exact ⟨a, b, hxab.1.trans hxab.2, hab⟩
  · rintro ⟨a, b, hab, h⟩
    obtain ⟨x, hax, hxb⟩ := exists_between hab
    refine ⟨x, (h x ⟨hax, hxb⟩).1, ?_⟩
    filter_upwards [Ioo_mem_nhds hax hxb] with y hy
    exact (h y hy).2


theorem countable_exactSet_of_no_localOne (t : SeedTerm) (h : ¬ LocalOne t) :
    (ExactSet t).Countable := by
  have hdisc : DiscreteTopology (ExactSet t) := by
    rw [discreteTopology_subtype_iff]
    intro x hx
    have hz := (analyticAt_value t hx.1).eventually_eq_or_eventually_ne
      (analyticAt_const (v := (1 : ℝ)))
    have hn : ∀ᶠ y in 𝓝[≠] x, value t y ≠ 1 :=
      hz.resolve_left (fun he => h ⟨x, hx.1, he⟩)
    rw [Filter.inf_principal_eq_bot]
    filter_upwards [hn] with y hy
    exact fun hmem => hy hmem.2
  letI := hdisc
  haveI : Countable (ExactSet t) := TopologicalSpace.separableSpace_iff_countable.mp inferInstance
  exact Set.to_countable _

def UniversalSeeds : Set ℝ := {x | 0 < x ∧ ∃ t, Valid t x ∧ value t x = 1}

theorem countable_universalSeeds_of_no_localOne (h : ∀ t, ¬ LocalOne t) :
    UniversalSeeds.Countable := by
  have hc : (⋃ t : SeedTerm, ExactSet t).Countable :=
    Set.countable_iUnion (fun t => countable_exactSet_of_no_localOne t (h t))
  apply hc.mono
  rintro x ⟨_, t, ht⟩
  exact Set.mem_iUnion.mpr ⟨t, ht⟩

def GroundValues (c : ℝ) : Set ℝ := {x | ∃ t, Valid t c ∧ value t c = x}

theorem groundValues_stable (c : ℝ) : PositiveSeeds.Stable (GroundValues c) := by
  rintro a ⟨ta, hva, hea⟩ b ⟨tb, hvb, heb⟩ hb
  refine ⟨node ta tb, ⟨hva, hvb, ?_⟩, ?_⟩
  · simpa [heb] using hb
  · simp [value, hea, heb]

theorem groundValues_dense {c : ℝ} (hc : 0 < c) : Dense (GroundValues c) := by
  rw [dense_iff_closure_eq]
  exact PositiveSeeds.closure_eq_univ (groundValues_stable c) ⟨leaf, trivial, rfl⟩ hc


theorem groundValues_countable (c : ℝ) : (GroundValues c).Countable := by
  apply (Set.countable_range (fun t : SeedTerm => value t c)).mono
  rintro x ⟨t, _, ht⟩
  exact ⟨t, ht⟩

theorem nonpositive_valid_leaf (t : SeedTerm) {c : ℝ} (hc : c ≤ 0)
    (hv : Valid t c) : t = leaf := by
  induction t with
  | leaf => rfl
  | node a b _ hb =>
      have he := hb hv.2.1
      have hp := hv.2.2
      rw [he] at hp
      exact False.elim ((not_lt_of_ge hc) hp)

theorem nonpositive_groundValues {c : ℝ} (hc : c ≤ 0) : GroundValues c = {c} := by
  ext x
  constructor
  · rintro ⟨t, ht, hx⟩
    have he := nonpositive_valid_leaf t hc ht
    simpa [he, value, Set.mem_singleton_iff] using hx.symm
  · intro hx
    exact ⟨leaf, trivial, (Set.mem_singleton_iff.mp hx).symm⟩

theorem localOne_transfers (t : SeedTerm) (h : LocalOne t) {c : ℝ}
    (hd : Dense (GroundValues c)) : ∃ s, Valid s c ∧ value s c = 1 := by
  obtain ⟨x, hx, hval⟩ := h
  have hn : ExactSet t ∈ 𝓝 x := by
    filter_upwards [(isOpen_valid t).mem_nhds hx, hval] with y hyv hye
    exact ⟨hyv, hye⟩
  obtain ⟨y, ⟨s, hsv, hse⟩, hyt⟩ := hd.inter_nhds_nonempty hn
  refine ⟨subst t s, (valid_subst t s c).mpr ⟨hsv, ?_⟩, ?_⟩
  · simpa [hse] using hyt.1
  · rw [value_subst, hse]
    exact hyt.2

/-- This theorem isolates the only external hypothesis needed to turn the
unconditional analytic result into the exact-seed dichotomy. -/
theorem exact_seed_dichotomy_of_density
    (hd : ∀ c : ℝ, 0 < c → Dense (GroundValues c)) :
    UniversalSeeds = Set.Ioi 0 ∨ UniversalSeeds.Countable := by
  by_cases h : ∃ t, LocalOne t
  · left
    apply Set.Subset.antisymm
    · exact fun _ hx => hx.1
    · intro c hc
      obtain ⟨t, ht⟩ := h
      exact ⟨hc, localOne_transfers t ht (hd c hc)⟩
  · right
    exact countable_universalSeeds_of_no_localOne (by simpa using h)


/-- The exact-seed dichotomy for actual strict EML syntax, with no extra assumptions. -/
theorem exact_seed_dichotomy :
    UniversalSeeds = Set.Ioi 0 ∨ UniversalSeeds.Countable :=
  exact_seed_dichotomy_of_density (fun _ hc => groundValues_dense hc)


theorem localOne_of_uncountable (h : ¬ UniversalSeeds.Countable) :
    ∃ t, LocalOne t := by
  by_contra hn
  exact h (countable_universalSeeds_of_no_localOne (by simpa using hn))

theorem all_seeds_of_localOne (h : ∃ t, LocalOne t) : UniversalSeeds = Set.Ioi 0 := by
  apply Set.Subset.antisymm
  · exact fun _ hx => hx.1
  · intro c hc
    obtain ⟨t, ht⟩ := h
    exact ⟨hc, localOne_transfers t ht (groundValues_dense hc)⟩

theorem all_seeds_of_uncountable (h : ¬ UniversalSeeds.Countable) :
    UniversalSeeds = Set.Ioi 0 := all_seeds_of_localOne (localOne_of_uncountable h)



theorem positive_reals_uncountable : ¬ (Set.Ioi (0 : ℝ)).Countable := by
  intro hc
  have hp := hc.preimage Real.exp_injective
  have hu : (Set.univ : Set ℝ).Countable := by
    simpa only [Set.preimage, Set.mem_Ioi, Real.exp_pos, Set.setOf_true] using hp
  exact Set.not_countable_univ hu

theorem all_seeds_iff_localOne :
    UniversalSeeds = Set.Ioi 0 ↔ ∃ t, LocalOne t := by
  constructor
  · intro he
    apply localOne_of_uncountable
    simpa [he] using positive_reals_uncountable
  · exact all_seeds_of_localOne

theorem all_seeds_iff_uncountable :
    UniversalSeeds = Set.Ioi 0 ↔ ¬ UniversalSeeds.Countable := by
  constructor
  · intro he
    simpa [he] using positive_reals_uncountable
  · exact all_seeds_of_uncountable

theorem all_seeds_iff_interval : UniversalSeeds = Set.Ioi 0 ↔
    ∃ (t : SeedTerm) (a b : ℝ), a < b ∧
      ∀ x ∈ Set.Ioo a b, Valid t x ∧ value t x = 1 := by
  rw [all_seeds_iff_localOne]
  exact exists_congr localOne_iff_interval


end ExactSeeds
