import Arithmetic
import Mathlib.Topology.Compactness.Compact

/-! Local strict-domain stability and uniform replacement of the named constant. -/
noncomputable section
open Filter Topology
namespace StrictEML

abbrev Input := ℝ × (Nat → ℝ)

def parameterVal : Term → Input → ℝ
  | .one, p => p.1
  | .var n, p => p.2 n
  | .node a b, p => Real.exp (parameterVal a p) - Real.log (parameterVal b p)

def parameterValid : Term → Input → Prop
  | .one, _ => True
  | .var _, _ => True
  | .node a b, p => parameterValid a p ∧ parameterValid b p ∧ 0 < parameterVal b p

theorem parameterVal_one (t : Term) (ρ : Nat → ℝ) : parameterVal t (1,ρ) = val t ρ := by
  induction t with
  | one => rfl
  | var n => rfl
  | node a b ia ib => simp only [parameterVal, val, ia, ib]

theorem parameterValid_one (t : Term) (ρ : Nat → ℝ) : parameterValid t (1,ρ) ↔ Valid t ρ := by
  induction t with
  | one => rfl
  | var n => rfl
  | node a b ia ib => simp only [parameterValid, Valid, ia, ib, parameterVal_one]

def replaceOne : Term → Term → Term
  | .one, s => s
  | .var n, _ => .var n
  | .node a b, s => .node (replaceOne a s) (replaceOne b s)

/-- Actual syntax substitution agrees with replacing the named value parameter. -/
theorem parameterVal_replaceOne (t s : Term) (p : Input) :
    parameterVal (replaceOne t s) p = parameterVal t (parameterVal s p, p.2) := by
  induction t with
  | one => rfl
  | var n => rfl
  | node a b ia ib => simp only [replaceOne, parameterVal, ia, ib]

/-- Strict definedness is preserved exactly by substitution of a defined expression. -/
theorem parameterValid_replaceOne (t s : Term) (p : Input) (hs : parameterValid s p) :
    parameterValid (replaceOne t s) p ↔ parameterValid t (parameterVal s p, p.2) := by
  induction t with
  | one => simpa only [replaceOne, parameterValid] using iff_true_intro hs
  | var n => rfl
  | node a b ia ib =>
    simp only [replaceOne, parameterValid, ia, ib, parameterVal_replaceOne]

/-- At every strictly valid input, validity persists locally and denotation is continuous. -/
theorem parameter_regular (t : Term) (p : Input) (h : parameterValid t p) :
    (∀ᶠ q in 𝓝 p, parameterValid t q) ∧ ContinuousAt (parameterVal t) p := by
  induction t with
  | one => exact ⟨Filter.Eventually.of_forall (fun _ => trivial), continuousAt_fst⟩
  | var n =>
    exact ⟨Filter.Eventually.of_forall (fun _ => trivial),
      ((continuous_apply n).comp continuous_snd).continuousAt⟩
  | node a b ia ib =>
    obtain ⟨ha,ca⟩ := ia h.1
    obtain ⟨hb,cb⟩ := ib h.2.1
    have hp : ∀ᶠ q in 𝓝 p, 0 < parameterVal b q := cb (Ioi_mem_nhds h.2.2)
    refine ⟨?_, (Real.continuous_exp.continuousAt.comp ca).sub (cb.log (ne_of_gt h.2.2))⟩
    filter_upwards [ha,hb,hp] with q hqa hqb hqp
    exact ⟨hqa,hqb,hqp⟩

/-- The natural domain is open in the joint constant-and-input space. -/
theorem parameter_domain_open (t : Term) : IsOpen {p : Input | parameterValid t p} := by
  exact isOpen_iff_mem_nhds.mpr (fun p hp => (parameter_regular t p hp).1)

/-- Replacing every 1-leaf by a nearby real preserves all strict domains uniformly on a compact
set and changes the value uniformly by less than any specified positive error. -/
theorem compact_parameter_stability (t : Term) {K : Set (Nat → ℝ)} (hK : IsCompact K)
    (hvalid : ∀ ρ ∈ K, Valid t ρ) {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ z in 𝓝 (1:ℝ), ∀ ρ ∈ K,
      parameterValid t (z,ρ) ∧ |parameterVal t (z,ρ) - val t ρ| < ε := by
  apply hK.eventually_forall_of_forall_eventually
  intro ρ hρ
  have h := parameter_regular t (1,ρ) ((parameterValid_one t ρ).mpr (hvalid ρ hρ))
  have hc : Continuous (fun p : Input => ((1:ℝ),p.2)) := continuous_const.prodMk continuous_snd
  have hbase : ContinuousAt (fun p : Input => parameterVal t (1,p.2)) (1,ρ) :=
    h.2.comp_of_eq hc.continuousAt rfl
  have herror : ContinuousAt (fun p : Input => |parameterVal t p - parameterVal t (1,p.2)|) (1,ρ) :=
    (h.2.sub hbase).abs
  have hlt : ∀ᶠ p : Input in 𝓝 (1,ρ),
      |parameterVal t p - parameterVal t (1,p.2)| < ε :=
    herror (Iio_mem_nhds (by simpa using hε))
  filter_upwards [h.1,hlt] with p hp he
  exact ⟨hp, by simpa only [parameterVal_one] using he⟩

end StrictEML
